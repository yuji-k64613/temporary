http://unageanu.hatenablog.com/entry/20090722/1248257955
https://www.ibm.com/support/knowledgecenter/ja/SSEQTP_9.0.5/com.ibm.websphere.base.doc/ae/twbs_jaxwsfromwsdl.html

javac jaxws/sample/HelloService.java
wsgen -cp ../src jaxws.sample.HelloService -wsdl
wsimport -s ../build HelloServiceService.wsdl

@WebMethod(action = "http://foo.com")
