package jaxws.sample;

import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * Webサービスとして公開するクラス。
 * 任意のPOJOをアノテーションで修飾すればOK
 */
@WebService
public class HelloService {

    @WebMethod
    public String hello() {
        return "Hello World!";
    }
}
